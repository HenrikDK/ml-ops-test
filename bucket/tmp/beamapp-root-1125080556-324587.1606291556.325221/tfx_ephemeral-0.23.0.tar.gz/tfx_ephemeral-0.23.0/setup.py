
import setuptools

if __name__ == '__main__':
  setuptools.setup(
      name='tfx_ephemeral',
      version='0.23.0',
      packages=setuptools.find_packages(),
      install_requires=[['absl-py>=0.7,<0.9', 'apache-beam[gcp]>=2.23,<3', 'attrs>=19.3.0,<20', 'click>=7,<8', 'docker>=4.1,<5', 'google-api-python-client>=1.7.8,<2', 'google-resumable-media>=0.6.0,<0.7.0', 'grpcio>=1.28.1,<2', 'jinja2>=2.7.3,<3', 'keras-tuner>=1,<2', 'kubernetes>=10.0.1,<12', 'ml-metadata>=0.23,<0.24', 'protobuf>=3.7,<4', 'pyarrow>=0.17,<0.18', 'pyyaml>=3.12,<6', 'six>=1.10,<2', 'tensorflow>=1.15.2,!=2.0.*,!=2.1.*,!=2.2.*,<3', 'tensorflow-data-validation>=0.23,<0.24', 'tensorflow-model-analysis>=0.23,<0.24', 'tensorflow-serving-api>=1.15,!=2.0.*,!=2.1.*,!=2.2.*,<3', 'tensorflow-transform>=0.23,<0.24', 'tfx-bsl>=0.23,<0.24']],
      )
